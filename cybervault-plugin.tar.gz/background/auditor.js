"use strict";
(() => {
  // src/domain/services/aitm/types.ts
  var WEIGHTS = {
    hostname: 0.25,
    "content-hash": 0.3,
    timing: 0.15,
    "dom-integrity": 0.2,
    "cookie-security": 0.1,
    "integrity-score": 0.25,
    "fingerprint-anomaly": 0.15
  };
  var THRESHOLDS = {
    block: 70,
    warn: 40
  };
  function computeRiskScore(signals) {
    let weightedSum = 0;
    let totalWeight = 0;
    for (const signal of signals) {
      const weight = WEIGHTS[signal.type] ?? 0;
      weightedSum += signal.score * weight;
      totalWeight += weight;
    }
    return totalWeight > 0 ? Math.round(weightedSum / totalWeight) : 0;
  }
  function getRecommendation(riskScore) {
    if (riskScore >= THRESHOLDS.block) {
      return "block";
    }
    if (riskScore >= THRESHOLDS.warn) {
      return "warn";
    }
    return "allow";
  }

  // src/domain/services/aitm/pipeline-orchestrator.ts
  var DEFAULT_PHASE_TIMEOUT_MS = 50;
  var DEFAULT_TOTAL_TIMEOUT_MS = 200;
  async function executeWithTimeout(step, hostname, expectedDomain, timeoutMs) {
    let timeoutHandle;
    const timeoutPromise = new Promise((resolve) => {
      timeoutHandle = setTimeout(() => {
        resolve({
          result: {
            isValid: false,
            strategy: step.name,
            riskLevel: "medium",
            confidence: 0,
            reason: `Phase "${step.name}" timed out after ${timeoutMs}ms`
          },
          timedOut: true
        });
      }, timeoutMs);
    });
    const executePromise = step.execute(hostname, expectedDomain).then((result) => ({
      result,
      timedOut: false
    }));
    executePromise.finally(() => {
      if (timeoutHandle) clearTimeout(timeoutHandle);
    });
    return Promise.race([executePromise, timeoutPromise]);
  }
  var PipelineOrchestrator = class {
    steps = [];
    phaseTimeoutMs;
    totalTimeoutMs;
    integrityEvaluator;
    currentFingerprint;
    baselineFingerprint;
    constructor(config) {
      this.phaseTimeoutMs = config?.phaseTimeoutMs ?? DEFAULT_PHASE_TIMEOUT_MS;
      this.totalTimeoutMs = config?.totalTimeoutMs ?? DEFAULT_TOTAL_TIMEOUT_MS;
      this.integrityEvaluator = config?.integrityEvaluator;
      this.currentFingerprint = config?.currentFingerprint;
      this.baselineFingerprint = config?.baselineFingerprint;
    }
    addStep(step) {
      this.steps.push(step);
    }
    async validate(hostname, expectedDomain) {
      const startTime = performance.now();
      const stepResults = [];
      const phaseErrors = [];
      const globalTimeout = new Promise((resolve) => {
        setTimeout(() => resolve({ timedOut: true }), this.totalTimeoutMs);
      });
      const execution = (async () => {
        for (let i = 0; i < this.steps.length; i++) {
          const step = this.steps[i];
          try {
            const { result, timedOut } = await executeWithTimeout(
              step,
              hostname,
              expectedDomain,
              this.phaseTimeoutMs
            );
            stepResults.push(result);
            if (timedOut) {
              phaseErrors.push({ phase: i + 1, error: `Timeout after ${this.phaseTimeoutMs}ms` });
              continue;
            }
            if (result.strategy === "ExactMatch" && result.isValid) {
              break;
            }
            if (result.strategy === "ConfusableDetection" && result.riskLevel === "high") {
              break;
            }
          } catch (err) {
            const errorMsg = err instanceof Error ? err.message : String(err);
            phaseErrors.push({ phase: i + 1, error: errorMsg });
            stepResults.push({
              isValid: false,
              strategy: step.name,
              riskLevel: "medium",
              confidence: 0,
              reason: `Phase "${step.name}" failed: ${errorMsg}`
            });
          }
        }
      })();
      await Promise.race([execution, globalTimeout]);
      let integrityResult;
      let combinedRiskScore = 0;
      let combinedRecommendation = "allow";
      if (this.integrityEvaluator && this.currentFingerprint) {
        const context = {
          currentFingerprint: this.currentFingerprint,
          baselineFingerprint: this.baselineFingerprint,
          url: this.currentFingerprint.url,
          timestamp: Date.now()
        };
        try {
          integrityResult = await this.integrityEvaluator.evaluate(context);
          const domainSignals = stepResults.map((step) => {
            const signalType = this.mapStrategyToSignalType(step.strategy);
            return {
              type: signalType,
              status: step.isValid ? "pass" : step.riskLevel === "high" ? "fail" : "warn",
              score: step.isValid ? 0 : step.riskLevel === "high" ? 100 : 50,
              confidence: step.confidence,
              weight: WEIGHTS[signalType],
              details: step.reason
            };
          });
          const allSignals = [
            ...domainSignals,
            ...integrityResult.signals
          ];
          combinedRiskScore = computeRiskScore(allSignals);
          combinedRecommendation = getRecommendation(combinedRiskScore);
        } catch (err) {
          console.warn("[PipelineOrchestrator] Integrity evaluation failed:", err);
        }
      }
      const totalTimeMs = performance.now() - startTime;
      const domainRisk = stepResults.some((r) => r.riskLevel === "high") ? "high" : stepResults.some((r) => r.riskLevel === "medium") ? "medium" : "low";
      const integrityRisk = integrityResult?.riskScore ?? 0;
      const integrityRiskLevel = integrityRisk >= THRESHOLDS.block ? "high" : integrityRisk >= THRESHOLDS.warn ? "medium" : "low";
      const overallRisk = domainRisk === "high" || integrityRiskLevel === "high" ? "high" : domainRisk === "medium" || integrityRiskLevel === "medium" ? "medium" : "low";
      const isValid = stepResults.length > 0 ? stepResults[stepResults.length - 1].isValid : true;
      const finalIsValid = isValid && combinedRiskScore < THRESHOLDS.block;
      return {
        steps: stepResults,
        overallRisk,
        isValid: finalIsValid,
        totalTimeMs,
        integrityResult
      };
    }
    /**
     * Map domain validation strategy to DetectionSignal type
     */
    mapStrategyToSignalType(strategy) {
      switch (strategy) {
        case "ExactMatch":
          return "hostname";
        case "ConfusableDetection":
          return "content-hash";
        case "LevenshteinTypoSquatting":
          return "timing";
        default:
          return "cookie-security";
      }
    }
  };

  // src/domain/utils/dns-normalize.ts
  function dnsNormalize(hostname) {
    return hostname.toLowerCase().trim().replace(/\.$/, "");
  }

  // src/domain/services/aitm/steps/exact-match-step.ts
  var ExactMatchStep = class {
    name = "ExactMatch";
    async execute(hostname, expectedDomain) {
      const normalizedHost = dnsNormalize(hostname);
      const normalizedExpected = dnsNormalize(expectedDomain);
      if (normalizedHost === normalizedExpected) {
        return {
          isValid: true,
          strategy: this.name,
          riskLevel: "low",
          confidence: 1,
          reason: `Hostname "${normalizedHost}" exactly matches expected domain "${normalizedExpected}"`
        };
      }
      const subdomainSuffix = `.${normalizedExpected}`;
      if (normalizedHost.endsWith(subdomainSuffix)) {
        return {
          isValid: true,
          strategy: this.name,
          riskLevel: "low",
          confidence: 1,
          reason: `Hostname "${normalizedHost}" is a valid subdomain of "${normalizedExpected}"`
        };
      }
      return {
        isValid: false,
        strategy: this.name,
        riskLevel: "high",
        confidence: 1,
        reason: `Hostname "${normalizedHost}" does not match expected domain "${normalizedExpected}" and is not a valid subdomain`
      };
    }
  };

  // src/domain/utils/confusables-data.ts
  var UNICODE_CONFUSABLES_MAP = [
    { char: "\u0430", codePoint: 1072, script: "Cyrillic", lookalike: "a", category: "homograph" },
    { char: "\u0435", codePoint: 1077, script: "Cyrillic", lookalike: "e", category: "homograph" },
    { char: "\u043E", codePoint: 1086, script: "Cyrillic", lookalike: "o", category: "homograph" },
    { char: "\u0440", codePoint: 1088, script: "Cyrillic", lookalike: "p", category: "homograph" },
    { char: "\u0441", codePoint: 1089, script: "Cyrillic", lookalike: "c", category: "homograph" },
    { char: "\u0443", codePoint: 1091, script: "Cyrillic", lookalike: "y", category: "homograph" },
    { char: "\u0445", codePoint: 1093, script: "Cyrillic", lookalike: "x", category: "homograph" },
    { char: "\u0456", codePoint: 1110, script: "Cyrillic", lookalike: "i", category: "homograph" },
    { char: "\u0458", codePoint: 1112, script: "Cyrillic", lookalike: "j", category: "homograph" },
    { char: "\u0455", codePoint: 1109, script: "Cyrillic", lookalike: "s", category: "homograph" },
    { char: "\u03B1", codePoint: 945, script: "Greek", lookalike: "a", category: "homograph" },
    { char: "\u03B2", codePoint: 946, script: "Greek", lookalike: "b", category: "homograph" },
    { char: "\u03B5", codePoint: 949, script: "Greek", lookalike: "e", category: "homograph" },
    { char: "\u03BF", codePoint: 959, script: "Greek", lookalike: "o", category: "homograph" },
    { char: "\u03C1", codePoint: 961, script: "Greek", lookalike: "p", category: "homograph" },
    { char: "\u03C4", codePoint: 964, script: "Greek", lookalike: "t", category: "homograph" },
    { char: "\u03C5", codePoint: 965, script: "Greek", lookalike: "y", category: "homograph" },
    { char: "\u03C7", codePoint: 967, script: "Greek", lookalike: "x", category: "homograph" },
    { char: "\u03B9", codePoint: 953, script: "Greek", lookalike: "i", category: "homograph" },
    { char: "\u03BA", codePoint: 954, script: "Greek", lookalike: "k", category: "homograph" },
    { char: "\u0561", codePoint: 1377, script: "Armenian", lookalike: "a", category: "homograph" },
    { char: "\u0565", codePoint: 1381, script: "Armenian", lookalike: "e", category: "homograph" },
    { char: "\u0585", codePoint: 1413, script: "Armenian", lookalike: "o", category: "homograph" },
    { char: "\u05D0", codePoint: 1488, script: "Hebrew", lookalike: "a", category: "homograph" },
    { char: "\u05E2", codePoint: 1506, script: "Hebrew", lookalike: "o", category: "homograph" },
    ...Array.from({ length: 94 }, (_, i) => ({
      char: String.fromCharCode(65281 + i),
      codePoint: 65281 + i,
      script: "Fullwidth",
      lookalike: String.fromCharCode(33 + i),
      category: "fullwidth"
    })),
    { char: "\u200B", codePoint: 8203, script: "Common", lookalike: "", category: "zerowidth" },
    { char: "\u200C", codePoint: 8204, script: "Common", lookalike: "", category: "zerowidth" },
    { char: "\u200D", codePoint: 8205, script: "Common", lookalike: "", category: "zerowidth" },
    { char: "\uFEFF", codePoint: 65279, script: "Common", lookalike: "", category: "zerowidth" },
    { char: "\xAD", codePoint: 173, script: "Common", lookalike: "", category: "zerowidth" },
    { char: "\u2060", codePoint: 8288, script: "Common", lookalike: "", category: "zerowidth" },
    { char: "\u2061", codePoint: 8289, script: "Common", lookalike: "", category: "zerowidth" },
    { char: "\u034F", codePoint: 847, script: "Common", lookalike: "", category: "combining" },
    { char: "\u{1D41A}", codePoint: 119834, script: "MathBold", lookalike: "a", category: "homograph" },
    { char: "\u{1D41E}", codePoint: 119838, script: "MathBold", lookalike: "e", category: "homograph" },
    { char: "\u{1D428}", codePoint: 119844, script: "MathBold", lookalike: "o", category: "homograph" },
    { char: "\xE0", codePoint: 224, script: "Latin", lookalike: "a", category: "homograph" },
    { char: "\xE1", codePoint: 225, script: "Latin", lookalike: "a", category: "homograph" },
    { char: "\xE2", codePoint: 226, script: "Latin", lookalike: "a", category: "homograph" },
    { char: "\xE3", codePoint: 227, script: "Latin", lookalike: "a", category: "homograph" },
    { char: "\xE4", codePoint: 228, script: "Latin", lookalike: "a", category: "homograph" },
    { char: "\xE5", codePoint: 229, script: "Latin", lookalike: "a", category: "homograph" },
    { char: "\xE8", codePoint: 232, script: "Latin", lookalike: "e", category: "homograph" },
    { char: "\xE9", codePoint: 233, script: "Latin", lookalike: "e", category: "homograph" },
    { char: "\xEA", codePoint: 234, script: "Latin", lookalike: "e", category: "homograph" },
    { char: "\xEB", codePoint: 235, script: "Latin", lookalike: "e", category: "homograph" },
    { char: "\xEC", codePoint: 236, script: "Latin", lookalike: "i", category: "homograph" },
    { char: "\xED", codePoint: 237, script: "Latin", lookalike: "i", category: "homograph" },
    { char: "\xEE", codePoint: 238, script: "Latin", lookalike: "i", category: "homograph" },
    { char: "\xEF", codePoint: 239, script: "Latin", lookalike: "i", category: "homograph" },
    { char: "\xF2", codePoint: 242, script: "Latin", lookalike: "o", category: "homograph" },
    { char: "\xF3", codePoint: 243, script: "Latin", lookalike: "o", category: "homograph" },
    { char: "\xF4", codePoint: 244, script: "Latin", lookalike: "o", category: "homograph" },
    { char: "\xF5", codePoint: 245, script: "Latin", lookalike: "o", category: "homograph" },
    { char: "\xF6", codePoint: 246, script: "Latin", lookalike: "o", category: "homograph" },
    { char: "\xF9", codePoint: 249, script: "Latin", lookalike: "u", category: "homograph" },
    { char: "\xFA", codePoint: 250, script: "Latin", lookalike: "u", category: "homograph" },
    { char: "\xFB", codePoint: 251, script: "Latin", lookalike: "u", category: "homograph" },
    { char: "\xFC", codePoint: 252, script: "Latin", lookalike: "u", category: "homograph" },
    { char: "\u2070", codePoint: 8304, script: "Superscript", lookalike: "0", category: "homograph" },
    { char: "\xB9", codePoint: 185, script: "Superscript", lookalike: "1", category: "homograph" },
    { char: "\xB2", codePoint: 178, script: "Superscript", lookalike: "2", category: "homograph" },
    { char: "\xB3", codePoint: 179, script: "Superscript", lookalike: "3", category: "homograph" }
  ];
  var CONFUSABLE_LOOKUP = new Map(
    UNICODE_CONFUSABLES_MAP.map((m) => [m.char, m])
  );
  var SCRIPT_RANGES = [
    { script: "Cyrillic", start: 1024, end: 1279 },
    { script: "Greek", start: 880, end: 1023 },
    { script: "Armenian", start: 1328, end: 1423 },
    { script: "Hebrew", start: 1424, end: 1535 },
    { script: "Arabic", start: 1536, end: 1791 },
    { script: "Devanagari", start: 2304, end: 2431 },
    { script: "Fullwidth", start: 65280, end: 65519 },
    { script: "MathBold", start: 119808, end: 120831 },
    { script: "LatinExtendedA", start: 256, end: 383 },
    { script: "LatinExtendedB", start: 384, end: 591 }
  ];

  // src/domain/utils/unicode-confusables.ts
  var ZERO_WIDTH_RE = /[\u200B\u200C\u200D\uFEFF\u2060\u00AD]/g;
  function stripZeroWidth(input) {
    return input.replace(ZERO_WIDTH_RE, "");
  }
  function detectConfusables(input) {
    const results = [];
    for (let i = 0; i < input.length; i++) {
      const ch = input[i];
      const cp = ch.codePointAt(0);
      if (cp === void 0) continue;
      const known = CONFUSABLE_LOOKUP.get(ch);
      if (known) {
        results.push({
          char: known.char,
          codePoint: known.codePoint,
          script: known.script,
          lookalike: known.lookalike,
          category: known.category,
          index: i
        });
        continue;
      }
      for (const range of SCRIPT_RANGES) {
        if (cp >= range.start && cp <= range.end) {
          results.push({
            char: ch,
            codePoint: cp,
            script: range.script,
            lookalike: "",
            category: "homograph",
            index: i
          });
          break;
        }
      }
    }
    return results;
  }

  // src/domain/services/aitm/steps/confusable-detection-step.ts
  var ConfusableDetectionStep = class {
    name = "ConfusableDetection";
    async execute(hostname, _expectedDomain) {
      const cleanHost = stripZeroWidth(hostname);
      const evidence = detectConfusables(cleanHost);
      if (evidence.length === 0) {
        return {
          isValid: true,
          strategy: this.name,
          riskLevel: "low",
          confidence: 1,
          reason: `No confusable characters detected in "${cleanHost}"`,
          evidence: []
        };
      }
      const scripts = [...new Set(evidence.map((e) => e.script))];
      const isHighRisk = scripts.includes("Cyrillic") || scripts.includes("Arabic") || scripts.includes("Fullwidth");
      const riskLevel = isHighRisk ? "high" : "medium";
      return {
        isValid: false,
        strategy: this.name,
        riskLevel,
        confidence: 0.95,
        reason: `Detected ${evidence.length} confusable character(s) from scripts: ${scripts.join(", ")}`,
        evidence
      };
    }
  };

  // src/domain/utils/levenshtein.ts
  var MAX_LENGTH = 100;
  function levenshteinSimilarity(a, b) {
    if (a.length > MAX_LENGTH || b.length > MAX_LENGTH) {
      throw new Error(
        `Input length exceeds hard limit (${MAX_LENGTH})`
      );
    }
    const m = a.length;
    const n = b.length;
    if (m === 0) return n === 0 ? 1 : 0;
    if (n === 0) return 0;
    const maxLen = Math.max(m, n);
    const prev = new Array(n + 1);
    const curr = new Array(n + 1);
    for (let j = 0; j <= n; j++) prev[j] = j;
    for (let i = 1; i <= m; i++) {
      curr[0] = i;
      const aChar = a[i - 1];
      for (let j = 1; j <= n; j++) {
        if (aChar === b[j - 1]) {
          curr[j] = prev[j - 1];
        } else {
          curr[j] = 1 + Math.min(prev[j], curr[j - 1], prev[j - 1]);
        }
      }
      for (let j = 0; j <= n; j++) prev[j] = curr[j];
    }
    const distance = prev[n];
    return 1 - distance / maxLen;
  }

  // src/domain/services/aitm/steps/typosquatting-step.ts
  var COMMON_TLDS = [
    ".com",
    ".org",
    ".net",
    ".edu",
    ".gov",
    ".co",
    ".io",
    ".info",
    ".biz",
    ".xyz"
  ];
  function stripTld(hostname) {
    let normalized = dnsNormalize(hostname);
    for (const tld of COMMON_TLDS) {
      if (normalized.endsWith(tld)) {
        normalized = normalized.slice(0, -tld.length);
        break;
      }
    }
    return normalized;
  }
  function extractRegistrableDomain(hostname) {
    const normalized = dnsNormalize(hostname);
    const withoutTld = stripTld(hostname);
    const registrableLabels = withoutTld.split(".");
    return registrableLabels[registrableLabels.length - 1] || normalized;
  }
  var TyposquattingStep = class {
    name = "LevenshteinTypoSquatting";
    threshold;
    constructor(threshold = 0.85) {
      this.threshold = threshold;
    }
    async execute(hostname, expectedDomain) {
      const currentRegistrable = extractRegistrableDomain(hostname);
      const expectedRegistrable = extractRegistrableDomain(expectedDomain);
      if (currentRegistrable === expectedRegistrable) {
        return {
          isValid: true,
          strategy: this.name,
          riskLevel: "low",
          confidence: 1,
          reason: `Registrable domain "${currentRegistrable}" exactly matches "${expectedRegistrable}"`,
          distance: 0
        };
      }
      const similarity = levenshteinSimilarity(
        currentRegistrable,
        expectedRegistrable
      );
      const distance = currentRegistrable.length > 0 && expectedRegistrable.length > 0 ? Math.round((1 - similarity) * Math.max(currentRegistrable.length, expectedRegistrable.length)) : 0;
      if (similarity >= this.threshold) {
        return {
          isValid: false,
          strategy: this.name,
          riskLevel: "high",
          confidence: similarity,
          reason: `Registrable domain "${currentRegistrable}" is similar to "${expectedRegistrable}" (similarity: ${similarity.toFixed(3)}, threshold: ${this.threshold})`,
          distance
        };
      }
      return {
        isValid: true,
        strategy: this.name,
        riskLevel: "low",
        confidence: similarity,
        reason: `Registrable domain "${currentRegistrable}" is sufficiently different from "${expectedRegistrable}" (similarity: ${similarity.toFixed(3)})`,
        distance
      };
    }
  };

  // src/infrastructure/repositories/chrome-storage-trust-store.ts
  var TRUST_STORE_KEY = "cybervault_trust_store";
  var FINGERPRINT_KEY_PREFIX = "cybervault_fp_";
  var MAX_TRUST_STORE_ENTRIES = 1e4;
  function validateDomain(domain) {
    if (/[\x00-\x1F\x7F]/.test(domain)) {
      throw new Error("Invalid domain: contains control characters");
    }
    if (/[<>"'&]/.test(domain)) {
      throw new Error("Invalid domain: contains dangerous characters");
    }
    if (domain.includes("\0")) {
      throw new Error("Invalid domain: contains null byte");
    }
    const normalized = dnsNormalize(domain);
    if (!normalized) {
      throw new Error("Invalid domain: empty after normalization");
    }
    if (!/^[a-z0-9.-]+$/.test(normalized)) {
      throw new Error("Invalid domain: contains invalid characters");
    }
    if (normalized.startsWith("-") || normalized.startsWith(".") || normalized.endsWith("-") || normalized.endsWith(".")) {
      throw new Error("Invalid domain: cannot start or end with hyphen or dot");
    }
    if (normalized.includes("..")) {
      throw new Error("Invalid domain: consecutive dots not allowed");
    }
    const labels = normalized.split(".");
    for (const label of labels) {
      if (label.length === 0) {
        throw new Error("Invalid domain: empty label");
      }
      if (label.length > 63) {
        throw new Error("Invalid domain: label too long (max 63 chars)");
      }
      if (label.startsWith("-") || label.endsWith("-")) {
        throw new Error("Invalid domain: label cannot start or end with hyphen");
      }
    }
    return normalized;
  }
  var ChromeStorageTrustStore = class {
    async save(entry) {
      const store = await this.getAll();
      const domain = validateDomain(entry.domain);
      const existing = store.find((e) => e.domain === domain);
      const now = Date.now();
      if (existing) {
        existing.trustLevel = entry.trustLevel;
        existing.lastSeen = now;
        existing.visitCount += 1;
        if (entry.fingerprint) {
          existing.fingerprint = entry.fingerprint;
        }
      } else {
        if (store.length >= MAX_TRUST_STORE_ENTRIES) {
          throw new Error("Trust store limit exceeded");
        }
        store.push({
          domain,
          trustLevel: entry.trustLevel,
          firstSeen: entry.firstSeen ?? now,
          lastSeen: now,
          fingerprint: entry.fingerprint,
          visitCount: 1
        });
      }
      await chrome.storage.local.set({ [TRUST_STORE_KEY]: store });
    }
    async findByDomain(domain) {
      const store = await this.getAll();
      const normalized = dnsNormalize(domain);
      return store.find((e) => e.domain === normalized) ?? null;
    }
    async revoke(domain) {
      const store = await this.getAll();
      const normalized = dnsNormalize(domain);
      const filtered = store.filter((e) => e.domain !== normalized);
      await chrome.storage.local.set({ [TRUST_STORE_KEY]: filtered });
    }
    async list() {
      return this.getAll();
    }
    async removeExpired(maxAgeMs) {
      const store = await this.getAll();
      const now = Date.now();
      const before = store.length;
      const filtered = store.filter((e) => now - e.lastSeen < maxAgeMs);
      await chrome.storage.local.set({ [TRUST_STORE_KEY]: filtered });
      return before - filtered.length;
    }
    /**
     * Persist a DOM fingerprint for a domain (session storage).
     * Survives service worker restarts during a browser session.
     */
    async saveFingerprint(domain, fingerprint) {
      const normalized = validateDomain(domain);
      const key = `${FINGERPRINT_KEY_PREFIX}${normalized}`;
      await chrome.storage.session.set({ [key]: { fingerprint, timestamp: Date.now() } });
    }
    /**
     * Get stored fingerprint for a domain.
     */
    async getFingerprint(domain) {
      const normalized = dnsNormalize(domain);
      const key = `${FINGERPRINT_KEY_PREFIX}${normalized}`;
      const result = await chrome.storage.session.get(key);
      const stored = result[key];
      if (stored && typeof stored === "object" && "fingerprint" in stored) {
        return stored.fingerprint;
      }
      return null;
    }
    /**
     * Remove stored fingerprint for a domain.
     */
    async removeFingerprint(domain) {
      const normalized = dnsNormalize(domain);
      const key = `${FINGERPRINT_KEY_PREFIX}${normalized}`;
      await chrome.storage.session.remove(key);
    }
    async getAll() {
      const result = await chrome.storage.local.get(TRUST_STORE_KEY);
      const entries = result[TRUST_STORE_KEY];
      if (!Array.isArray(entries)) return [];
      return entries;
    }
  };

  // src/shared/metrics.ts
  var MetricsCollector = class {
    metrics = /* @__PURE__ */ new Map();
    histograms = /* @__PURE__ */ new Map();
    counter(name, help, labels) {
      const key = this.key(name, labels);
      const existing = this.metrics.get(key);
      if (existing) {
        existing.value++;
      } else {
        this.metrics.set(key, { type: "counter", help, value: 1, labels });
      }
    }
    gauge(name, help, value, labels) {
      const key = this.key(name, labels);
      this.metrics.set(key, { type: "gauge", help, value, labels });
    }
    histogram(name, help, value, labels) {
      const key = this.key(name, labels);
      let hist = this.histograms.get(key);
      if (!hist) {
        hist = { values: [], buckets: [0.01, 0.05, 0.1, 0.25, 0.5, 1, 2.5, 5, 10] };
        this.histograms.set(key, hist);
        this.metrics.set(key, { type: "histogram", help, value: 0, labels });
      }
      hist.values.push(value);
    }
    key(name, labels) {
      if (!labels) return name;
      const sorted = Object.entries(labels).sort().map(([k, v]) => `${k}="${v}"`).join(",");
      return `${name}{${sorted}}`;
    }
    labelStr(labels) {
      if (!labels || Object.keys(labels).length === 0) return "";
      const sorted = Object.entries(labels).sort().map(([k, v]) => `${k}="${v}"`).join(",");
      return `{${sorted}}`;
    }
    formatPrometheus() {
      const lines = [];
      const seenHelp = /* @__PURE__ */ new Set();
      for (const [key, metric] of this.metrics) {
        const baseName = key.split("{")[0];
        if (!seenHelp.has(baseName)) {
          lines.push(`# HELP ${baseName} ${metric.help}`);
          lines.push(`# TYPE ${baseName} ${metric.type}`);
          seenHelp.add(baseName);
        }
        if (metric.type === "histogram") {
          const hist = this.histograms.get(key);
          if (hist && hist.values.length > 0) {
            const sorted = [...hist.values].sort((a, b) => a - b);
            const sum = sorted.reduce((a, b) => a + b, 0);
            const count = sorted.length;
            const base = baseName;
            const labelPrefix = this.labelStr(metric.labels);
            for (const bucket of hist.buckets) {
              const le = sorted.filter((v) => v <= bucket).length;
              const labels = labelPrefix ? `${labelPrefix.slice(0, -1)},le="${bucket}"}` : `{le="${bucket}"}`;
              lines.push(`${base}_bucket${labels} ${le}`);
            }
            const infLabels = labelPrefix ? `${labelPrefix.slice(0, -1)},le="+Inf"}` : `{le="+Inf"}`;
            lines.push(`${base}_bucket${infLabels} ${count}`);
            lines.push(`${base}_sum${labelPrefix} ${sum.toFixed(6)}`);
            lines.push(`${base}_count${labelPrefix} ${count}`);
          }
        } else {
          lines.push(`${key} ${metric.value}`);
        }
      }
      return lines.join("\n") + "\n";
    }
    /**
     * Returns the series recorded for a metric family (label sets + values).
     * Used by the health check summary and diagnostics.
     */
    series(name) {
      const result = [];
      for (const [key, metric] of this.metrics) {
        if (key === name || key.startsWith(`${name}{`)) {
          result.push({ labels: metric.labels, value: metric.value });
        }
      }
      return result;
    }
    reset() {
      this.metrics.clear();
      this.histograms.clear();
    }
  };
  var metrics = new MetricsCollector();

  // src/shared/logger.ts
  var LOG_LEVELS = {
    debug: 0,
    info: 1,
    warn: 2,
    error: 3
  };
  var _logLevel = typeof process !== "undefined" && "info" || "info";
  var _logFormat = typeof process !== "undefined" && "json" || "json";
  var MIN_LEVEL = LOG_LEVELS[_logLevel] ?? LOG_LEVELS.info;
  function formatEntry(entry) {
    if (_logFormat === "json") {
      return JSON.stringify(entry);
    }
    const ctx = entry.context ? `[${entry.context}]` : "";
    const data = entry.data ? ` ${JSON.stringify(entry.data)}` : "";
    const err = entry.error ? ` error=${entry.error}` : "";
    return `${entry.timestamp} ${entry.level.toUpperCase().padEnd(5)} ${ctx} ${entry.message}${data}${err}`;
  }
  function log(level, message, context, data, error) {
    if (LOG_LEVELS[level] < MIN_LEVEL) return;
    const entry = {
      timestamp: (/* @__PURE__ */ new Date()).toISOString(),
      level,
      message,
      context,
      data,
      error
    };
    const formatted = formatEntry(entry);
    switch (level) {
      case "error":
        console.error(formatted);
        break;
      case "warn":
        console.warn(formatted);
        break;
      default:
        console.log(formatted);
    }
  }
  var logger = {
    debug: (message, context, data) => log("debug", message, context, data),
    info: (message, context, data) => log("info", message, context, data),
    warn: (message, context, data) => log("warn", message, context, data),
    error: (message, context, data, error) => log("error", message, context, data, error)
  };

  // src/background/auditor.ts
  var MESSAGE_TYPES = {
    VALIDATE_DOMAIN: "VALIDATE_DOMAIN",
    GET_TRUST_STATUS: "GET_TRUST_STATUS",
    REPORT_ANOMALY: "REPORT_ANOMALY",
    UNLOCK_VAULT: "UNLOCK_VAULT"
  };
  var trustStore = new ChromeStorageTrustStore();
  function createPipeline() {
    const pipeline = new PipelineOrchestrator();
    pipeline.addStep(new ExactMatchStep());
    pipeline.addStep(new ConfusableDetectionStep());
    pipeline.addStep(new TyposquattingStep());
    return pipeline;
  }
  async function handleValidateDomain(msg) {
    try {
      const pipeline = createPipeline();
      const result = await pipeline.validate(msg.hostname, msg.expectedDomain);
      metrics.counter(
        "cybervault_aitm_detections_total",
        "Total AiTM detections",
        { risk_level: result.overallRisk }
      );
      const trustLevel = result.overallRisk === "high" ? "suspicious" : "trusted";
      await trustStore.save({
        domain: msg.hostname,
        trustLevel,
        firstSeen: Date.now(),
        lastSeen: Date.now(),
        visitCount: 1
      });
      await chrome.storage.local.set({
        [`cybervault_last_validation_${msg.hostname}`]: {
          result,
          timestamp: Date.now()
        }
      });
      return { ok: true, data: result };
    } catch (err) {
      const message = err instanceof Error ? err.message : String(err);
      return { ok: false, error: message };
    }
  }
  async function handleGetTrustStatus(msg) {
    try {
      const entry = await trustStore.findByDomain(msg.domain);
      return { ok: true, data: entry };
    } catch (err) {
      const message = err instanceof Error ? err.message : String(err);
      return { ok: false, error: message };
    }
  }
  async function handleReportAnomaly(msg) {
    try {
      const key = "cybervault_anomaly_log";
      const stored = await chrome.storage.local.get(key);
      const log2 = Array.isArray(stored[key]) ? stored[key] : [];
      log2.push({
        domain: msg.domain,
        anomalyType: msg.anomalyType,
        severity: msg.severity,
        details: msg.details,
        timestamp: Date.now()
      });
      if (log2.length > 500) {
        log2.splice(0, log2.length - 500);
      }
      await chrome.storage.local.set({ [key]: log2 });
      if (msg.severity === "high") {
        await trustStore.save({
          domain: msg.domain,
          trustLevel: "suspicious",
          firstSeen: Date.now(),
          lastSeen: Date.now(),
          visitCount: 1
        });
      }
      return { ok: true };
    } catch (err) {
      const message = err instanceof Error ? err.message : String(err);
      return { ok: false, error: message };
    }
  }
  async function handleUnlockVault(msg) {
    try {
      await chrome.storage.session.set({
        cybervault_unlock_state: {
          vaultId: msg.vaultId,
          unlockedAt: Date.now(),
          expiresAt: Date.now() + 30 * 60 * 1e3
          // 30 min session
        }
      });
      return { ok: true, data: { unlocked: true } };
    } catch (err) {
      const message = err instanceof Error ? err.message : String(err);
      return { ok: false, error: message };
    }
  }
  chrome.runtime.onMessage.addListener(
    (message, _sender, sendResponse) => {
      let handlerPromise;
      switch (message.type) {
        case MESSAGE_TYPES.VALIDATE_DOMAIN:
          handlerPromise = handleValidateDomain(message);
          break;
        case MESSAGE_TYPES.GET_TRUST_STATUS:
          handlerPromise = handleGetTrustStatus(message);
          break;
        case MESSAGE_TYPES.REPORT_ANOMALY:
          handlerPromise = handleReportAnomaly(message);
          break;
        case MESSAGE_TYPES.UNLOCK_VAULT:
          handlerPromise = handleUnlockVault(message);
          break;
        default:
          sendResponse({
            ok: false,
            error: `Unknown message type: ${message.type}`
          });
          return false;
      }
      handlerPromise.then((response) => sendResponse(response)).catch((err) => {
        const errorMsg = err instanceof Error ? err.message : String(err);
        sendResponse({ ok: false, error: errorMsg });
      });
      return true;
    }
  );
  chrome.runtime.onInstalled.addListener(
    async (details) => {
      const { reason } = details;
      if (reason === "install") {
        await chrome.storage.local.set({
          cybervault_settings: {
            autoValidate: true,
            blockHighRisk: true,
            showNotifications: true,
            sessionTimeoutMinutes: 30
          },
          cybervault_anomaly_log: []
        });
        logger.info("Extension installed \u2014 default settings seeded", "Auditor");
      }
      if (reason === "update") {
        const trustEntries = await trustStore.list();
        const expiredCount = await trustStore.removeExpired(
          90 * 24 * 60 * 60 * 1e3
          // 90 days
        );
        if (expiredCount > 0) {
          logger.info(
            `Cleaned ${expiredCount} expired trust entries (${trustEntries.length} remaining)`,
            "Auditor"
          );
        }
      }
    }
  );
})();
//# sourceMappingURL=auditor.js.map
