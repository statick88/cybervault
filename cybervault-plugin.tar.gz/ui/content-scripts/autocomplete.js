"use strict";
(() => {
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __commonJS = (cb, mod) => function __require() {
    return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
  };

  // src/ui/content-scripts/autocomplete.ts
  var require_autocomplete = __commonJS({
    "src/ui/content-scripts/autocomplete.ts"() {
      (function() {
        const INDICATOR_ID = "cybervault-autocomplete-indicator";
        const FILL_ATTR = "data-cv-filled";
        const STORAGE_PREFIX = "cybervault_creds_";
        function domainKey(domain) {
          return `${STORAGE_PREFIX}${domain}`;
        }
        async function getCredentialsForDomain(domain) {
          try {
            const result = await chrome.storage.local.get(domainKey(domain));
            const cred = result[domainKey(domain)];
            if (cred && typeof cred === "object" && "email" in cred && "password" in cred) {
              return cred;
            }
            return null;
          } catch {
            return null;
          }
        }
        async function markLastUsed(domain) {
          try {
            const key = domainKey(domain);
            const result = await chrome.storage.local.get(key);
            const cred = result[key];
            if (cred && typeof cred === "object") {
              cred["lastUsed"] = Date.now();
              await chrome.storage.local.set({ [key]: cred });
            }
          } catch {
          }
        }
        function detectCredentialFields(form) {
          const inputs = form.querySelectorAll(
            'input[type="text"], input[type="email"], input[type="password"]'
          );
          let emailField = null;
          let passwordField = null;
          inputs.forEach((input) => {
            const type = input.type.toLowerCase();
            const name = (input.name || "").toLowerCase();
            const id = (input.id || "").toLowerCase();
            const autocomplete = (input.getAttribute("autocomplete") || "").toLowerCase();
            const placeholder = (input.placeholder || "").toLowerCase();
            if (type === "password" && !passwordField) {
              passwordField = input;
            } else if (type === "email" || autocomplete.includes("email") || name.includes("email") || id.includes("email") || placeholder.includes("email") || placeholder.includes("correo")) {
              if (!emailField) emailField = input;
            } else if (type === "text" && !emailField && (name.includes("user") || name.includes("login") || id.includes("user"))) {
              emailField = input;
            }
          });
          return { emailField, passwordField };
        }
        function fillField(input, value) {
          if (input.getAttribute(FILL_ATTR)) return;
          const nativeSetter = Object.getOwnPropertyDescriptor(
            HTMLInputElement.prototype,
            "value"
          )?.set;
          if (nativeSetter) {
            nativeSetter.call(input, value);
          } else {
            input.value = value;
          }
          input.setAttribute(FILL_ATTR, "true");
          input.dispatchEvent(new Event("input", { bubbles: true }));
          input.dispatchEvent(new Event("change", { bubbles: true }));
        }
        function showIndicator(email) {
          if (document.getElementById(INDICATOR_ID)) return;
          const badge = document.createElement("div");
          badge.id = INDICATOR_ID;
          badge.style.cssText = `
    position:fixed;top:8px;right:8px;z-index:2147483646;
    background:#1a1a2e;border:1px solid #00ff88;border-radius:6px;
    padding:6px 12px;font-size:12px;color:#00ff88;
    font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;
    box-shadow:0 2px 8px rgba(0,255,136,0.2);cursor:pointer;
    transition:opacity 0.2s;
  `;
          badge.textContent = `\u{1F510} CyberVault: ${email}`;
          badge.title = "Click to auto-fill saved credentials";
          badge.addEventListener("click", () => {
            fillAllForms();
            badge.style.opacity = "0";
            setTimeout(() => badge.remove(), 200);
          });
          document.body.appendChild(badge);
        }
        async function fillAllForms() {
          const domain = window.location.hostname;
          const cred = await getCredentialsForDomain(domain);
          if (!cred) return;
          const forms = document.querySelectorAll("form");
          forms.forEach((form) => {
            const { emailField, passwordField } = detectCredentialFields(form);
            if (emailField && cred.email) {
              fillField(emailField, cred.email);
            }
            if (passwordField && cred.password) {
              fillField(passwordField, cred.password);
            }
          });
          await markLastUsed(domain);
        }
        async function main() {
          const domain = window.location.hostname;
          if (!domain) return;
          const cred = await getCredentialsForDomain(domain);
          if (!cred) return;
          showIndicator(cred.email);
          await fillAllForms();
          const observer = new MutationObserver(() => {
            const forms = document.querySelectorAll(
              `form:not([${FILL_ATTR}])`
            );
            if (forms.length > 0) {
              fillAllForms();
            }
          });
          if (document.body) {
            observer.observe(document.body, { childList: true, subtree: true });
          }
        }
        if (document.readyState === "loading") {
          document.addEventListener("DOMContentLoaded", main);
        } else {
          main();
        }
      })();
    }
  });
  require_autocomplete();
})();
//# sourceMappingURL=autocomplete.js.map
