"use strict";
(() => {
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __commonJS = (cb, mod) => function __require() {
    return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
  };

  // src/ui/content-scripts/inject.ts
  var require_inject = __commonJS({
    "src/ui/content-scripts/inject.ts"() {
      (function() {
        const CYBERVAULT_BLOCKED_CLASS = "cybervault-blocked";
        const FORM_SUBMIT_SELECTOR = "form";
        let lastValidationResult = null;
        let blockedForms = /* @__PURE__ */ new WeakSet();
        function generateFingerprint() {
          const forms = document.querySelectorAll("form");
          const loginForms = document.querySelectorAll(
            'input[type="password"]'
          );
          const inputs = document.querySelectorAll(
            "form input, form select"
          );
          const inputNames = [];
          inputs.forEach((input) => {
            if (input.name) inputNames.push(input.name);
          });
          return {
            url: window.location.href,
            hostname: window.location.hostname,
            formCount: forms.length,
            loginFormCount: loginForms.length,
            inputNames: [...new Set(inputNames)]
          };
        }
        async function validateDomain(hostname) {
          try {
            const response = await chrome.runtime.sendMessage(
              {
                type: "VALIDATE_DOMAIN",
                hostname,
                expectedDomain: hostname
              }
            );
            if (response?.ok && response.data) {
              return response.data;
            }
            return null;
          } catch {
            return null;
          }
        }
        function showBlockingAlert(hostname, risk) {
          const overlay = document.createElement("div");
          overlay.id = "cybervault-phishing-overlay";
          overlay.className = CYBERVAULT_BLOCKED_CLASS;
          const container = document.createElement("div");
          container.style.cssText = "position:fixed;top:0;left:0;width:100%;height:100%;background:rgba(0,0,0,0.85);z-index:2147483647;display:flex;align-items:center;justify-content:center;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;";
          const card = document.createElement("div");
          card.style.cssText = "background:#1a1a2e;border:2px solid #ff4444;border-radius:12px;padding:32px;max-width:480px;text-align:center;color:#fff;box-shadow:0 8px 32px rgba(255,0,0,0.3);";
          const icon = document.createElement("div");
          icon.style.cssText = "font-size:48px;margin-bottom:16px";
          icon.textContent = "\u26A0\uFE0F";
          const title = document.createElement("h2");
          title.style.cssText = "margin:0 0 12px;color:#ff4444;font-size:20px";
          title.textContent = "Phishing Detected";
          const desc = document.createElement("p");
          desc.style.cssText = "margin:0 0 8px;color:#ccc;font-size:14px";
          desc.appendChild(document.createTextNode("CyberVault has flagged this domain as "));
          const strong = document.createElement("strong");
          const safeRisk = ["high", "medium", "low", "critical"].includes(risk.toLowerCase()) ? risk : "unknown";
          strong.textContent = safeRisk;
          desc.appendChild(strong);
          desc.appendChild(document.createTextNode(" risk."));
          const domainLine = document.createElement("p");
          domainLine.style.cssText = "margin:0 0 20px;color:#888;font-size:13px";
          domainLine.appendChild(document.createTextNode("Domain: "));
          const code = document.createElement("code");
          code.style.cssText = "color:#ff8888";
          code.textContent = hostname;
          domainLine.appendChild(code);
          const btn = document.createElement("button");
          btn.id = "cybervault-dismiss-btn";
          btn.style.cssText = "padding:10px 24px;background:#ff4444;color:#fff;border:none;border-radius:6px;cursor:pointer;font-size:14px;font-weight:bold";
          btn.textContent = "I understand the risk \u2014 continue";
          card.append(icon, title, desc, domainLine, btn);
          container.appendChild(card);
          overlay.appendChild(container);
          document.body.appendChild(overlay);
          overlay.querySelector("#cybervault-dismiss-btn")?.addEventListener("click", () => {
            overlay.remove();
          });
        }
        function interceptFormSubmit(form) {
          if (blockedForms.has(form)) return;
          form.addEventListener(
            "submit",
            (event) => {
              if (lastValidationResult && lastValidationResult.overallRisk !== "low") {
                event.preventDefault();
                event.stopPropagation();
                if (!blockedForms.has(form)) {
                  blockedForms.add(form);
                  showBlockingAlert(
                    window.location.hostname,
                    lastValidationResult.overallRisk
                  );
                }
                return false;
              }
            },
            true
          );
        }
        function scanForLoginForms() {
          const passwordInputs = document.querySelectorAll(
            'input[type="password"]'
          );
          passwordInputs.forEach((input) => {
            const form = input.closest("form");
            if (form) {
              interceptFormSubmit(form);
            }
          });
        }
        async function main() {
          const hostname = window.location.hostname;
          if (!hostname) return;
          const result = await validateDomain(hostname);
          if (result) {
            lastValidationResult = result;
            if (result.overallRisk !== "low") {
              showBlockingAlert(hostname, result.overallRisk);
            }
          }
          scanForLoginForms();
          const observer = new MutationObserver((mutations) => {
            let shouldScan = false;
            for (const mutation of mutations) {
              if (mutation.addedNodes.length > 0) {
                shouldScan = true;
                break;
              }
            }
            if (shouldScan) {
              scanForLoginForms();
            }
          });
          observer.observe(document.body, {
            childList: true,
            subtree: true
          });
        }
        if (document.readyState === "loading") {
          document.addEventListener("DOMContentLoaded", main);
        } else {
          main();
        }
      })();
    }
  });
  require_inject();
})();
//# sourceMappingURL=inject.js.map
