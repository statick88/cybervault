"use strict";
(() => {
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __commonJS = (cb, mod) => function __require() {
    return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
  };

  // src/ui/options/options.ts
  var require_options = __commonJS({
    "src/ui/options/options.ts"() {
      (function() {
        const SETTINGS_KEY = "cybervault_settings";
        const TRUSTED_DOMAINS_KEY = "cybervault_trusted_domains";
        const ANOMALY_LOG_KEY = "cybervault_anomaly_log";
        const VAULT_KEY = "vault_data";
        const $ = (sel) => document.querySelector(sel);
        const domainInput = $("#domain-input");
        const domainAddBtn = $("#domain-add");
        const domainList = $("#domain-list");
        const cfgAutoValidate = $("#cfg-auto-validate");
        const cfgBlockHighRisk = $("#cfg-block-high-risk");
        const cfgShowNotifications = $("#cfg-show-notifications");
        const cfgSessionTimeout = $("#cfg-session-timeout");
        const exportBtn = $("#export-btn");
        const importBtn = $("#import-btn");
        const importFile = $("#import-file");
        const dataStatus = $("#data-status");
        const anomalyLog = $("#anomaly-log");
        const anomalyEmpty = $("#anomaly-empty");
        async function readStorage(key) {
          const result = await chrome.storage.local.get([key]);
          return result[key];
        }
        async function writeStorage(data) {
          await chrome.storage.local.set(data);
        }
        function showStatus(msg, type = "success") {
          dataStatus.textContent = msg;
          dataStatus.className = `data-status data-status--${type}`;
          dataStatus.hidden = false;
          setTimeout(() => dataStatus.hidden = true, 3e3);
        }
        function formatDate(ts) {
          return new Date(ts).toLocaleString();
        }
        async function loadDomains() {
          const domains = await readStorage(TRUSTED_DOMAINS_KEY);
          return Array.isArray(domains) ? domains : [];
        }
        async function renderDomains() {
          const domains = await loadDomains();
          domainList.innerHTML = "";
          for (const domain of domains) {
            const li = document.createElement("li");
            li.className = "domain-item";
            const span = document.createElement("span");
            span.textContent = domain;
            const removeBtn = document.createElement("button");
            removeBtn.className = "domain-item__remove";
            removeBtn.textContent = "\xD7";
            removeBtn.title = `Remove ${domain}`;
            removeBtn.addEventListener("click", () => removeDomain(domain));
            li.appendChild(span);
            li.appendChild(removeBtn);
            domainList.appendChild(li);
          }
        }
        async function addDomain() {
          const domain = domainInput.value.trim().toLowerCase();
          if (!domain) return;
          const domains = await loadDomains();
          if (domains.includes(domain)) {
            domainInput.value = "";
            return;
          }
          domains.push(domain);
          await writeStorage({ [TRUSTED_DOMAINS_KEY]: domains });
          domainInput.value = "";
          await renderDomains();
        }
        async function removeDomain(domain) {
          let domains = await loadDomains();
          domains = domains.filter((d) => d !== domain);
          await writeStorage({ [TRUSTED_DOMAINS_KEY]: domains });
          await renderDomains();
        }
        async function loadSettings() {
          const defaults = {
            autoValidate: true,
            blockHighRisk: true,
            showNotifications: true,
            sessionTimeoutMinutes: 30
          };
          const stored = await readStorage(SETTINGS_KEY);
          return stored ? { ...defaults, ...stored } : defaults;
        }
        async function saveSettings() {
          const settings = {
            autoValidate: cfgAutoValidate.checked,
            blockHighRisk: cfgBlockHighRisk.checked,
            showNotifications: cfgShowNotifications.checked,
            sessionTimeoutMinutes: Math.max(1, parseInt(cfgSessionTimeout.value, 10) || 30)
          };
          await writeStorage({ [SETTINGS_KEY]: settings });
          showStatus("Settings saved");
        }
        async function populateSettings() {
          const s = await loadSettings();
          cfgAutoValidate.checked = s.autoValidate;
          cfgBlockHighRisk.checked = s.blockHighRisk;
          cfgShowNotifications.checked = s.showNotifications;
          cfgSessionTimeout.value = String(s.sessionTimeoutMinutes);
        }
        async function handleExport() {
          const vault = await readStorage(VAULT_KEY);
          if (!vault) {
            showStatus("No vault to export", "error");
            return;
          }
          const blob = new Blob([JSON.stringify(vault, null, 2)], {
            type: "application/json"
          });
          const url = URL.createObjectURL(blob);
          const a = document.createElement("a");
          a.href = url;
          a.download = `cybervault-export-${Date.now()}.json`;
          a.click();
          URL.revokeObjectURL(url);
          showStatus("Vault exported");
        }
        function handleImportClick() {
          importFile.click();
        }
        async function handleImportFile() {
          const file = importFile.files?.[0];
          if (!file) return;
          try {
            const text = await file.text();
            const data = JSON.parse(text);
            if (!data || typeof data !== "object") {
              throw new Error("Invalid vault file format");
            }
            await writeStorage({ [VAULT_KEY]: data });
            showStatus("Vault imported successfully");
          } catch (err) {
            const msg = err instanceof Error ? err.message : "Import failed";
            showStatus(msg, "error");
          } finally {
            importFile.value = "";
          }
        }
        async function loadAnomalyLog() {
          const log = await readStorage(ANOMALY_LOG_KEY);
          const entries = Array.isArray(log) ? log : [];
          anomalyLog.innerHTML = "";
          if (entries.length === 0) {
            anomalyEmpty.hidden = false;
            return;
          }
          anomalyEmpty.hidden = true;
          const recent = entries.slice(-50).reverse();
          for (const entry of recent) {
            const li = document.createElement("li");
            li.className = "anomaly-item";
            const domain = document.createElement("span");
            domain.className = "anomaly-item__domain";
            domain.textContent = entry.domain;
            const severity = document.createElement("span");
            severity.className = `anomaly-item__severity anomaly-item__severity--${entry.severity}`;
            severity.textContent = entry.severity;
            const time = document.createElement("span");
            time.className = "anomaly-item__time";
            time.textContent = formatDate(entry.timestamp);
            li.appendChild(domain);
            li.appendChild(severity);
            li.appendChild(time);
            anomalyLog.appendChild(li);
          }
        }
        domainAddBtn.addEventListener("click", addDomain);
        domainInput.addEventListener("keydown", (e) => {
          if (e.key === "Enter") addDomain();
        });
        cfgAutoValidate.addEventListener("change", saveSettings);
        cfgBlockHighRisk.addEventListener("change", saveSettings);
        cfgShowNotifications.addEventListener("change", saveSettings);
        cfgSessionTimeout.addEventListener("change", saveSettings);
        exportBtn.addEventListener("click", handleExport);
        importBtn.addEventListener("click", handleImportClick);
        importFile.addEventListener("change", handleImportFile);
        (async () => {
          await Promise.all([
            renderDomains(),
            populateSettings(),
            loadAnomalyLog()
          ]);
        })();
      })();
    }
  });
  require_options();
})();
//# sourceMappingURL=options.js.map
