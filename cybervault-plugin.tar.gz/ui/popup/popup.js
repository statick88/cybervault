"use strict";
(() => {
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __commonJS = (cb, mod) => function __require() {
    return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
  };

  // src/ui/popup/popup.ts
  var require_popup = __commonJS({
    "src/ui/popup/popup.ts"() {
      (function() {
        const VAULT_KEY = "vault_data";
        const SETTINGS_KEY = "cybervault_settings";
        const UNLOCK_STATE_KEY = "cybervault_unlock_state";
        const AUTH_TOKEN_KEY = "cybervault_token";
        const USER_ID_KEY = "cybervault_userId";
        const $ = (sel) => document.querySelector(sel);
        const loginView = $("#login-view");
        const lockedView = $("#locked-view");
        const unlockedView = $("#unlocked-view");
        const loginForm = $("#login-form");
        const loginEmail = $("#login-email");
        const loginPassword = $("#login-password");
        const loginBtn = $("#login-btn");
        const loginError = $("#login-error");
        const passphraseInput = $("#passphrase-input");
        const unlockBtn = $("#unlock-btn");
        const lockError = $("#lock-error");
        const lockToggle = $("#lock-toggle");
        const lockIcon = $("#lock-icon");
        const searchInput = $("#search-input");
        const addBtn = $("#add-btn");
        const credentialList = $("#credential-list");
        const emptyState = $("#empty-state");
        const addForm = $("#add-form");
        const addTitle = $("#add-title");
        const addUsername = $("#add-username");
        const addPassword = $("#add-password");
        const addUrl = $("#add-url");
        const addSave = $("#add-save");
        const addCancel = $("#add-cancel");
        const optionsLink = $("#options-link");
        let isUnlocked = false;
        let credentials = [];
        let authToken = null;
        const API_BASE = "http://localhost:3010";
        async function sendMessage(message) {
          return chrome.runtime.sendMessage(message);
        }
        async function readStorage(key) {
          const result = await chrome.storage.local.get([key]);
          return result[key];
        }
        async function writeStorage(data) {
          await chrome.storage.local.set(data);
        }
        const ENCRYPTION_CONFIG = {
          AES: { ALGORITHM: "AES-GCM", KEY_LENGTH: 256, IV_LENGTH: 12, TAG_LENGTH: 128 },
          PBKDF2: { ALGORITHM: "PBKDF2", HASH: "SHA-512", ITERATIONS: 6e5, SALT_LENGTH: 16 }
        };
        function base64ToBinary(base64) {
          const binaryString = atob(base64);
          const bytes = new Uint8Array(binaryString.length);
          for (let i = 0; i < binaryString.length; i++) {
            bytes[i] = binaryString.charCodeAt(i);
          }
          return bytes;
        }
        async function decryptVault(encryptedData, masterKey) {
          const combined = base64ToBinary(encryptedData);
          const saltLength = ENCRYPTION_CONFIG.PBKDF2.SALT_LENGTH;
          const ivLength = ENCRYPTION_CONFIG.AES.IV_LENGTH;
          const salt = combined.slice(0, saltLength);
          const iv = combined.slice(saltLength, saltLength + ivLength);
          const ciphertextWithTag = combined.slice(saltLength + ivLength);
          const keyMaterial = await crypto.subtle.importKey(
            "raw",
            new TextEncoder().encode(masterKey),
            "PBKDF2",
            false,
            ["deriveKey"]
          );
          const aesKey = await crypto.subtle.deriveKey(
            {
              name: "PBKDF2",
              salt,
              iterations: ENCRYPTION_CONFIG.PBKDF2.ITERATIONS,
              hash: ENCRYPTION_CONFIG.PBKDF2.HASH
            },
            keyMaterial,
            { name: ENCRYPTION_CONFIG.AES.ALGORITHM, length: ENCRYPTION_CONFIG.AES.KEY_LENGTH },
            false,
            ["decrypt"]
          );
          const decryptedBuffer = await crypto.subtle.decrypt(
            {
              name: ENCRYPTION_CONFIG.AES.ALGORITHM,
              iv,
              tagLength: ENCRYPTION_CONFIG.AES.TAG_LENGTH
            },
            aesKey,
            ciphertextWithTag
          );
          return new TextDecoder().decode(decryptedBuffer);
        }
        async function handleLogin(e) {
          e.preventDefault();
          loginError.hidden = true;
          const email = loginEmail.value.trim();
          const password = loginPassword.value;
          if (!email || !password) {
            loginError.textContent = "Email y contrase\xF1a requeridos";
            loginError.hidden = false;
            return;
          }
          loginBtn.disabled = true;
          loginBtn.textContent = "Ingresando...";
          try {
            const res = await fetch(`${API_BASE}/api/v1/auth/login`, {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify({ email, password })
            });
            const data = await res.json();
            if (res.ok && data.token) {
              authToken = data.token;
              await writeStorage({
                [AUTH_TOKEN_KEY]: data.token,
                [USER_ID_KEY]: data.userId,
                "cybervault_email": email
              });
              showView("locked");
              passphraseInput.focus();
            } else {
              loginError.textContent = data.error || "Credenciales incorrectas";
              loginError.hidden = false;
            }
          } catch (err) {
            loginError.textContent = `Error de conexi\xF3n: ${err instanceof Error ? err.message : err}`;
            loginError.hidden = false;
          } finally {
            loginBtn.disabled = false;
            loginBtn.textContent = "Iniciar Sesi\xF3n";
          }
        }
        function showView(view) {
          loginView.hidden = view !== "login";
          lockedView.hidden = view !== "locked";
          unlockedView.hidden = view !== "unlocked";
          lockToggle.hidden = view === "login";
          if (view === "unlocked") {
            lockIcon.textContent = "\u{1F513}";
            lockToggle.setAttribute("aria-label", "Lock vault");
          } else {
            lockIcon.textContent = "\u{1F512}";
            lockToggle.setAttribute("aria-label", "Unlock vault");
          }
        }
        async function checkAuthState() {
          authToken = await readStorage(AUTH_TOKEN_KEY);
          const unlockState = await chrome.storage.session.get([UNLOCK_STATE_KEY]);
          const state = unlockState[UNLOCK_STATE_KEY];
          if (state && Date.now() < state.expiresAt) {
            showView("unlocked");
            await loadCredentials();
          } else if (authToken) {
            showView("locked");
          } else {
            showView("login");
          }
        }
        async function handleUnlock() {
          const passphrase = passphraseInput.value.trim();
          if (!passphrase) {
            lockError.textContent = "Passphrase required";
            lockError.hidden = false;
            return;
          }
          lockError.hidden = true;
          unlockBtn.disabled = true;
          unlockBtn.textContent = "Descifrando...";
          try {
            const vaultRes = await fetch(`${API_BASE}/api/v1/vaults`, {
              headers: { "Authorization": `Bearer ${authToken}` }
            });
            if (vaultRes.status === 401) {
              await writeStorage({ [AUTH_TOKEN_KEY]: null });
              authToken = null;
              showView("login");
              return;
            }
            const vaultData = await vaultRes.json();
            if (!vaultData.vaults || vaultData.vaults.length === 0) {
              lockError.textContent = "No vault found. Create one in the web app first.";
              lockError.hidden = false;
              return;
            }
            const vault = vaultData.vaults[0];
            const unlockRes = await fetch(`${API_BASE}/api/v1/vaults/${vault.id}/unlock`, {
              method: "POST",
              headers: {
                "Authorization": `Bearer ${authToken}`,
                "Content-Type": "application/json"
              }
            });
            if (!unlockRes.ok) {
              throw new Error("Failed to fetch vault data");
            }
            const unlockData = await unlockRes.json();
            const decrypted = await decryptVault(unlockData.encryptedData, passphrase);
            const parsedCredentials = JSON.parse(decrypted);
            await writeStorage({ [VAULT_KEY]: { ...vault, metadata: { credentials: parsedCredentials } } });
            await chrome.storage.session.set({
              [UNLOCK_STATE_KEY]: {
                vaultId: vault.id,
                unlockedAt: Date.now(),
                expiresAt: Date.now() + 30 * 60 * 1e3
              }
            });
            showView("unlocked");
            passphraseInput.value = "";
            await loadCredentials();
          } catch (err) {
            console.error("Unlock failed:", err);
            lockError.textContent = "Frase maestra incorrecta o error al descifrar";
            lockError.hidden = false;
          } finally {
            unlockBtn.disabled = false;
            unlockBtn.textContent = "Unlock";
          }
        }
        async function handleLock() {
          await chrome.storage.session.remove(UNLOCK_STATE_KEY);
          await chrome.storage.local.remove(VAULT_KEY);
          isUnlocked = false;
          credentials = [];
          credentialList.innerHTML = "";
          showView("locked");
        }
        async function loadCredentials() {
          const vaultData = await readStorage(VAULT_KEY);
          if (!vaultData?.metadata?.credentials) {
            credentials = [];
            renderCredentialList([]);
            return;
          }
          credentials = vaultData.metadata.credentials;
          renderCredentialList(credentials);
        }
        function renderCredentialList(items) {
          credentialList.innerHTML = "";
          if (items.length === 0) {
            emptyState.hidden = false;
            return;
          }
          emptyState.hidden = true;
          for (const cred of items) {
            const li = document.createElement("li");
            li.className = "credential-item";
            li.dataset.id = cred.id;
            const info = document.createElement("div");
            info.className = "credential-item__info";
            const title = document.createElement("div");
            title.className = "credential-item__title";
            title.textContent = cred.title;
            const user = document.createElement("div");
            user.className = "credential-item__user";
            user.textContent = cred.username;
            info.appendChild(title);
            info.appendChild(user);
            const actions = document.createElement("div");
            actions.className = "credential-item__actions";
            const copyUserBtn = document.createElement("button");
            copyUserBtn.className = "credential-item__btn";
            copyUserBtn.textContent = "\u{1F464}";
            copyUserBtn.title = "Copy username";
            copyUserBtn.addEventListener("click", () => copyToClipboard(cred.username, copyUserBtn));
            const copyPassBtn = document.createElement("button");
            copyPassBtn.className = "credential-item__btn";
            copyPassBtn.textContent = "\u{1F511}";
            copyPassBtn.title = "Copy password";
            copyPassBtn.addEventListener("click", () => copyToClipboard(cred.password, copyPassBtn));
            actions.appendChild(copyUserBtn);
            actions.appendChild(copyPassBtn);
            li.appendChild(info);
            li.appendChild(actions);
            credentialList.appendChild(li);
          }
        }
        async function copyToClipboard(text, btn) {
          try {
            await navigator.clipboard.writeText(text);
            btn.classList.add("credential-item__btn--copied");
            setTimeout(() => btn.classList.remove("credential-item__btn--copied"), 1200);
          } catch {
            const textarea = document.createElement("textarea");
            textarea.value = text;
            textarea.style.position = "fixed";
            textarea.style.opacity = "0";
            document.body.appendChild(textarea);
            textarea.select();
            document.execCommand("copy");
            document.body.removeChild(textarea);
            btn.classList.add("credential-item__btn--copied");
            setTimeout(() => btn.classList.remove("credential-item__btn--copied"), 1200);
          }
        }
        function handleSearch() {
          const query = searchInput.value.trim().toLowerCase();
          if (!query) {
            renderCredentialList(credentials);
            return;
          }
          const filtered = credentials.filter(
            (c) => c.title.toLowerCase().includes(query) || c.username.toLowerCase().includes(query) || c.url?.toLowerCase().includes(query) || c.tags.some((t) => t.toLowerCase().includes(query))
          );
          renderCredentialList(filtered);
        }
        function showAddForm() {
          addForm.hidden = false;
          addTitle.focus();
        }
        function hideAddForm() {
          addForm.hidden = true;
          addTitle.value = "";
          addUsername.value = "";
          addPassword.value = "";
          addUrl.value = "";
        }
        async function handleAddCredential() {
          const title = addTitle.value.trim();
          const username = addUsername.value.trim();
          const password = addPassword.value;
          const url = addUrl.value.trim();
          if (!title || !username || !password) {
            return;
          }
          const newCred = {
            id: crypto.randomUUID(),
            vaultId: "",
            title,
            username,
            password,
            url: url || void 0,
            tags: [],
            favorite: false,
            createdAt: (/* @__PURE__ */ new Date()).toISOString(),
            updatedAt: (/* @__PURE__ */ new Date()).toISOString()
          };
          const vaultData = await readStorage(VAULT_KEY);
          if (vaultData) {
            const existing = vaultData.metadata?.credentials || [];
            existing.push(newCred);
            vaultData.metadata = { ...vaultData.metadata, credentials: existing };
            vaultData.updatedAt = (/* @__PURE__ */ new Date()).toISOString();
            await writeStorage({ [VAULT_KEY]: vaultData });
          }
          hideAddForm();
          await loadCredentials();
        }
        function openOptions() {
          chrome.runtime.openOptionsPage();
        }
        loginForm.addEventListener("submit", handleLogin);
        unlockBtn.addEventListener("click", handleUnlock);
        passphraseInput.addEventListener("keydown", (e) => {
          if (e.key === "Enter") handleUnlock();
        });
        lockToggle.addEventListener("click", () => {
          if (isUnlocked) handleLock();
          else {
            showView("locked");
            passphraseInput.focus();
          }
        });
        searchInput.addEventListener("input", handleSearch);
        addBtn.addEventListener("click", showAddForm);
        addCancel.addEventListener("click", hideAddForm);
        addSave.addEventListener("click", handleAddCredential);
        optionsLink.addEventListener("click", (e) => {
          e.preventDefault();
          openOptions();
        });
        checkAuthState();
      })();
    }
  });
  require_popup();
})();
//# sourceMappingURL=popup.js.map
